# Paket CRUD Manajemen Perpustakaan (versi Breeze)

## Isi paket ini
- `app/Http/Controllers/*.php` → **replace** file controller kamu yang sudah ada (bug validasi & method edit/update/destroy kosong sudah diperbaiki)
- `resources/views/layouts/navigation.blade.php` → **replace** file navigasi Breeze kamu, sudah ditambah menu Kelas/Siswa/Author/Kategori/Buku
- `resources/views/components/flash-messages.blade.php` → komponen pesan sukses/error, dipanggil otomatis lewat `<x-flash-messages />` di tiap halaman
- `resources/views/{kelas,siswa,author,kategori,buku}/*.blade.php` → halaman index (tabel), create (form tambah), edit (form ubah), semua pakai `<x-app-layout>` bawaan Breeze kamu — masing-masing modul punya halaman sendiri sesuai permintaan
- `routes/web.php` → root `/` diarahkan ke halaman login Breeze kamu yang sudah ada (kalau sudah login → ke dashboard). Semua route resource dipindah ke dalam middleware `auth`.
- `database/seeders/AdminUserSeeder.php` → membuat 1 akun admin

Model kamu (`author.php`, `buku.php`, `kategori.php`, `kelas.php`, `siswa.php`) dan `layouts/app.blade.php` + `auth/login.blade.php` bawaan Breeze kamu **tidak perlu diubah**, sudah dipakai apa adanya.

## Langkah pemasangan

1. **Copy file controller** ke `app/Http/Controllers/` (timpa yang lama).
2. **Copy `navigation.blade.php`** ke `resources/views/layouts/` (timpa yang lama).
3. **Copy `flash-messages.blade.php`** ke `resources/views/components/` (buat folder `components` kalau belum ada).
4. **Copy semua folder view** (kelas, siswa, author, kategori, buku) ke `resources/views/`.
5. **Copy `routes/web.php`** — timpa file lama.
6. **Copy seeder** ke `database/seeders/AdminUserSeeder.php`.
7. Jalankan migrasi (kalau belum):
   ```bash
   php artisan migrate
   ```
8. Buat akun admin:
   ```bash
   php artisan db:seed --class=AdminUserSeeder
   ```
   Login dengan:
   - Email: `admin@perpus.test`
   - Password: `password123`

   **Ganti password ini lewat halaman Profile setelah login pertama kali.**

9. **Matikan pendaftaran akun baru** (karena sistem ini cuma untuk 1 admin) — buka `routes/auth.php`, lalu hapus/comment blok route `register`:
   ```php
   // Route::get('register', [RegisteredUserController::class, 'create'])
   //     ->name('register');
   // Route::post('register', [RegisteredUserController::class, 'store']);
   ```
   Kalau ada link "Register" di halaman login Breeze bawaan (`resources/views/auth/login.blade.php`), hapus juga linknya.

10. Jalankan project:
    ```bash
    php artisan serve
    ```
    Buka `http://localhost:8000` → akan diarahkan ke halaman login Breeze kamu.

## Catatan
- Semua route CRUD (`kelas`, `siswa`, `author`, `kategori`, `buku`) sekarang wajib login dulu.
- Kelas & Author/Kategori tidak bisa dihapus kalau masih dipakai Siswa/Buku (biar tidak error foreign key) — controller sudah menangani ini dengan pesan error.
- Form Siswa & Buku otomatis menampilkan dropdown relasi (Siswa → pilih Kelas, Buku → pilih Author & Kategori).
- Semua halaman pakai `<x-app-layout>` bawaan Breeze kamu, jadi otomatis dapat navbar, dropdown profile, dark mode, dll dari layout aslimu — tidak ada layout baru yang menimpa punyamu.