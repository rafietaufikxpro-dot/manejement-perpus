<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Data Buku
        </h2>
    </x-slot>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6">
                <x-flash-messages />

                <div class="flex items-center justify-between mb-4">
                    <form method="GET" class="flex gap-2">
                        <input type="text" name="search" value="{{ request('search') }}" placeholder="Cari judul buku..."
                               class="border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-200 rounded-md px-3 py-2 text-sm w-64">
                        <button type="submit" class="bg-slate-700 text-white px-4 py-2 rounded-md text-sm hover:bg-slate-800">Cari</button>
                    </form>
                    <a href="{{ route('buku.create') }}" class="bg-blue-600 text-white px-4 py-2 rounded-md text-sm hover:bg-blue-700">
                        + Tambah Buku
                    </a>
                </div>

                <table class="w-full text-sm text-left">
                    <thead class="bg-gray-50 dark:bg-gray-700 text-gray-600 dark:text-gray-300 uppercase text-xs">
                        <tr>
                            <th class="px-4 py-3">#</th>
                            <th class="px-4 py-3">Judul Buku</th>
                            <th class="px-4 py-3">Author</th>
                            <th class="px-4 py-3">Kategori</th>
                            <th class="px-4 py-3">Jumlah</th>
                            <th class="px-4 py-3 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 dark:divide-gray-700 dark:text-gray-200">
                        @forelse ($bukus as $item)
                            <tr>
                                <td class="px-4 py-3">{{ $loop->iteration + ($bukus->currentPage() - 1) * $bukus->perPage() }}</td>
                                <td class="px-4 py-3">{{ $item->judulbuku }}</td>
                                <td class="px-4 py-3">{{ $item->author->namaauthor ?? '-' }}</td>
                                <td class="px-4 py-3">{{ $item->kategori->namakategori ?? '-' }}</td>
                                <td class="px-4 py-3">{{ $item->jumlahbuku }}</td>
                                <td class="px-4 py-3 text-right space-x-2">
                                    <a href="{{ route('buku.edit', $item->id) }}" class="text-blue-600 hover:underline">Edit</a>
                                    <form action="{{ route('buku.destroy', $item->id) }}" method="POST" class="inline"
                                          onsubmit="return confirm('Yakin hapus buku ini?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="text-red-600 hover:underline">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="px-4 py-6 text-center text-gray-400">Belum ada data buku.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>

                <div class="mt-4">
                    {{ $bukus->links() }}
                </div>
            </div>
        </div>
    </div>
</x-app-layout>