<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\buku;
class bukucontroller extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view("buku.index");
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view("buku.create");
    }

    /** 'judulbuku' => 'required',
           
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
       $request->validate([
             'author_id' => 'required',
            'kategori_id' => 'required',
            'jumlahbuku' => 'required|integer',
        ]);
        buku::create($request->all());
        return redirect()->route('buku.index')->with('success', 'Buku created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
